clear;
clc;

[dst_dir,~]=fileparts(mfilename('fullpath'));
img_dir=uigetdir(dst_dir,'Please select the directory of original images');
load([dst_dir,'\ImageDataNames.mat']);
load([dst_dir,'\ROIs_W_H.mat']);
load([dst_dir,'\ROIs_x_y.mat']);
ImageDataSet = cell(length(ImageDataNames),1);

Siz = 512;
flag_which = 'equal';
        
for i=1:length(ImageDataNames)
    canvas = uint8(255*ones(Siz,Siz,3));
    name = [char(ImageDataNames(i)),'.png'];
    img = imread([img_dir,'\',name]);
    [R,C,D] = size(img);
    W = ROIs_W_H(i,1);
    H = ROIs_W_H(i,2);
    x = ROIs_x_y(i,1)+1;
    y = ROIs_x_y(i,2)+1;
    X = x + W - 1;
    Y = y + H - 1;
    if Y>R
        Y = R;
    end
    if X > C
        X = C;
    end
    im = img(y:Y,x:X,:);
    [r,c,~]=size(im);
    
    if H >= Siz || W >= Siz
        if H >= W
        	scaler = Siz / H;
        	flag_which = 'H_larger';
        else
        	scaler = Siz / W;
        	flag_which = 'W_larger';
        end
    else
    	scaler = 1;
    end
    
    if H >= Siz || W >= Siz
        if strcmp(flag_which,'H_larger')
            r = Siz;
            c = round(scaler * c);
        end
        if strcmp(flag_which,'W_larger')
            r = round(scaler * r);
            c = Siz;
        end
        im = imresize(im, [r,c]);
    end
    
    canvas(1:r,1:c,:) = im;
    ImageDataSet{i,1} = canvas;
end

save([dst_dir,'\','ImageDataSet'],'ImageDataSet');